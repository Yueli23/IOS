//
//  ViewController.swift
//  ScrollView2
//
//  Created by 南希 on 2018/11/27.
//  Copyright © 2018年 NanXi. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UIScrollViewDelegate{

    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var ScrollView: UIScrollView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        for i in 1...3{
            let imageView = UIImageView(image: UIImage(named: "\(i)"))
            imageView.contentMode = .scaleAspectFit
            imageView.frame = CGRect(x:CGFloat(i-1)*ScrollView.bounds.width,y:0,width:ScrollView.bounds.width,height:ScrollView.bounds.height)
            ScrollView.addSubview(imageView)
            ScrollView.isPagingEnabled = true
        }
        // Do any additional setup after loading the view, typically from a nib.
      
        ScrollView.contentSize = CGSize(width:7 * ScrollView.bounds.width,height:ScrollView.bounds.height)
//        ScrollView.minimumZoomScale = 0.2
//        ScrollView.maximumZoomScale = 5
        ScrollView.delegate = self
        pageControl.numberOfPages = 5
        pageControl.currentPage = 0
        pageControl.isUserInteractionEnabled = true
        ScrollView.showsVerticalScrollIndicator = false
        
    }
    
//    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
//        return scrollView.subviews.first
//    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        pageControl.currentPage = Int(scrollView.contentOffset.x / scrollView.bounds.width)
    }

    @IBAction func pageControlClocked(_ sender: UIPageControl) {
        let rect = CGRect(x:CGFloat(pageControl.currentPage)*ScrollView.bounds.width,y:0,width:ScrollView.bounds.width,height:ScrollView.bounds.height)
        ScrollView.scrollRectToVisible(rect, animated: true)
    }
}

